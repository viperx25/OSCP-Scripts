#!/usr/bin/zsh

export PATH=$PATH:/home/kali/OSCP-Scripts/enum:/home/kali/OSCP-Scripts/linux
