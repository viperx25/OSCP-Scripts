### OSCP Scripts

oh yeah
